1) Added in Synthesis boxes
2) Next update: Electrolytic cell